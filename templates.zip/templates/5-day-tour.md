# 5-Day Bus Tour Sample

## Day 1: Departure & Arrival
- Depart Toronto in the morning
- Arrive in Old Quebec City
- Hotel check-in, welcome dinner

## Day 2: Explore Quebec City
- Château Frontenac
- Old Port walk
- Group dinner

## Day 3: Scenic Drive East
- Hopewell Rocks (low tide)
- Moncton lunch stop
- Overnight in Edmundston

## Day 4: Free Day & Optional Mass
- Free time or casino
- Optional Mass

## Day 5: Return to Toronto
- Morning check-out
- Travel with lunch stop
